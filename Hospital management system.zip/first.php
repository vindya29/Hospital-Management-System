<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

</head>
</style type="text/css">
	#ab1:hover{cursor:pointer;}
>/style>

<body style="background:url('loginpage.jpg') no-repeat; background-size:cover; ">
<div class="container" style="width:400px;margin-top:100px;">
<div class="card">
<img src="images/back.jpg" class="card-img-top">
<div class="card-body">

	<form class="forn-group" action="func.php" method="post">
		<label>Admin name :</label><br>
		<input type="text" name="username" class="form-control" placeholder="enter username"><br>
		<label>Password :</label><br>
		<input type="password" name="password" class="form-control" placeholder="enter password"><br>
		<input type="submit" name="login_submit" id="ab1" class="btn btn-primary">
	</form>



</div>
</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

</body>

</html>
